<?php
echo "Tu nombre es ".$_POST['nombre']. "<br>";
echo "Tu apellido es ".$_POST['apellido']. "<br>";
?>
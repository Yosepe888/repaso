<?php
//variable e verdadero
$boleana = true;
echo "El valor de la variable es ".$boleana;
//variable en false
echo "<br>";
$boleana = false;
echo "El valor de la variable es ".$boleana;
?>
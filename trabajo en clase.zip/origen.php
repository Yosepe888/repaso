<?php
//pricnipal
echo "Yo soy el contenido original";
@include "incluido.php";
?>
<?php
 $uno = 1;
 $dos = 2;
//&& para el y o and
echo ($uno == 1 && $dos == 2);
echo "<br>";
$tres = 3;
$cuatro = 4;
// || para el 0 o or
echo ($tres == 3 || $cuatro == 3);
echo "<br>";
$cinco = 5;
$seis = 6;
//negacion ! es el not
echo $cinco!==$seis;
?>
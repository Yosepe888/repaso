<?php
echo 3-2;
echo "<br>";
echo 4*2;
echo "<br>";
echo 20 / 5;
echo "<br>";
echo 20 % 6;
echo "<br>";
echo "<br>";
echo "Utiliza variables para hacer operaciones de incremento y decremento";
echo "<br>";echo "<br>";
$primera = 3;
echo $primera++;
echo "<br>";
echo $primera;
echo "<br>";

$segunda = 3;
echo $primera--;
echo "<br>";
echo $primera;
?>
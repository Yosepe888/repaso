<?php
//creamos una matrzi unidemensional llamada frutas
$fruta[0] = "manzana";
$fruta[1] = "pera";
$fruta[2] = "fresa";

//for para escribir valores de la matriz
for ($numero=0;$numero<=2;$numero++) {
    echo $fruta[$numero]."<br>";
}
?>
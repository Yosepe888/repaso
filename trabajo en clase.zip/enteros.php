<?php
//DEFINE Y ASIGNA 
$entero = 5;
//mostrar valor
echo $entero;
echo "<br>";
//define variable decimal, se separa con .
$decimal = 5.432;
//muestra valor
echo $decimal;
echo "<br>";
//define variable científica, se separa con .
$cientifica = 0.123e2;
//muestra valor
echo $cientifica;
?>
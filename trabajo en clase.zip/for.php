<?php

for($numero=1;$numero<=10;$numero=$numero+1){
    echo "Hace ".$numero." veces que paso por aqui<br>";
}
echo "La operacion ha finalizado";

?>
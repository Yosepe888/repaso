<?php
echo "Tu nombre es ".$_GET['nombre']. "<br>";
echo "Tu apellido es ".$_GET['apellido']. "<br>";
?>
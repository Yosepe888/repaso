<?php
//definir matriz con unos valores
$matriz = array("coche","casa","moto","cuidad","moto");
//recorre la matriz por cada elemento y lo coloca en valor
foreach($matriz as $valor) {
    //escribir valor
    echo $valor."<br>";
    
}
?>
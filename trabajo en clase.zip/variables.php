<html>
<head>
   
</head>
<body>
    <h1>DEFINIR VARIABLES</h1>
    <?php
//Definir variable como texto
$miVariable = "Hola variable";
//Variable en explorador
echo $miVariable;
//Asignar valor
echo "<br>";
$miValor = 2;
//Operaciones
echo 3*$miValor;
?>
</body>
</html>
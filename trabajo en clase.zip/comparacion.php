<?php
//se usa ==
echo  1 == 1;
echo "<br>";
// se usa != para diferente identico
echo 3 !== "3";
echo"<br>";
if(2>=3) {echo "3 es mayor que dos";}
else
{echo "tres no es mayor que dos";}
?>
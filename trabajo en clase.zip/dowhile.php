<?php
//define variable
$variable = 1;

do {
    echo "Hola";
    //evalua variable, como es mayor, se sale.
} while ($variable > 2);

echo " Ya he finalizado";
?>
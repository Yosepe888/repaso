<?php
//se asigna variable al valor
$mivariable = 7;
//ver valor
echo $mivariable;
echo "<br>";
//incrementar variable
$mivariable +=5;
//ver resultado
echo $mivariable;
echo "<br>";
//decrementar variable
$mivariable -=5;
//ver resultado
echo $mivariable;
echo "<br>";
//multiplica variable
$mivariable *=5;
//ver resultado
echo $mivariable;
echo "<br>";
//dividir variable
$mivariable /=5;
//ver resultado
echo $mivariable;
?>
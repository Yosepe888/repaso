<?php
//se puede usar de ambas formas
echo "soy una 'cadena'<br>";
echo 'soy una "cadena"<br>';
//es mejor usar
echo "soy una \"cadena\" y estoy obligada<br>";
// \n permite el salto de línea
echo "yo soy una linea /n y yo soy la otra"
?>
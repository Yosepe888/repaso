<?php
//definir variable
$variable = 3;
//evalua el valor de variable y como es igual a 3 hace el caso 3
switch ($variable){
    case (1) :
    echo "La variable es igual a 1";
    break;

    case (2) :
        echo "La variable es igual a 2";
    break;

    case (3) :
    echo "La variable es igual a ¡Hola Mundo!";
    break;
}
<?php
$mi = "Mi nombre es";
$nombre = " Maria Fernanda";
$saludo = " y te saludo";

echo $mi.$nombre.$saludo;
?>
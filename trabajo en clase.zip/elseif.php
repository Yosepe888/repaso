<?php
//definir variable
$miVariable = "rojo";
//pregunta si variable es igual a rojo
if ($miVariable == "rojo") {
    echo "El color si que es rojo";
} else {
    echo "Parece que el color no coincide";
}
?>